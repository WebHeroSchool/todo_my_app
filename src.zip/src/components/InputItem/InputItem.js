import React from 'react';
import TextField from '@material-ui/core/TextField';

const InputItem = () => (<div>
	<TextField
    id="standard-helperText"
    label="Ввести название урока"
    defaultValue=""
  />
</div>);

export default InputItem;