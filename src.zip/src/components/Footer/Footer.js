import React from 'react';

const Footer = ({count}) => (<p>
  Сколько еще нужно сделать уроков: {count}
</p>);

export default Footer;