import React from 'react';
import Button from '@material-ui/core/Button';
//import ButtonGroup from '@material-ui/core/ButtonGroup';
import styles from './Footer.module.css';

const Footer = ({count}) => (<div className={styles.footer}>
	<p className={styles.footer__count}>Осталось уроков: {count}</p>
	
	<div className={styles.footer__filters}>
    	
    	<Button variant="outlined">Default</Button>
        	<Button variant="outlined">Default</Button>
        	<Button variant="outlined">Default</Button>
	</div>
</div>

);




export default Footer;